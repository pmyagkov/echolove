/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _consts = __webpack_require__(5);

	var _consts2 = _interopRequireDefault(_consts);

	function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

	function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var ButtonsController = function () {
	  function ButtonsController() {
	    _classCallCheck(this, ButtonsController);

	    this._initMutationObserver();

	    this._startObserving(true);
	  }

	  ButtonsController.prototype._initMutationObserver = function _initMutationObserver() {
	    var _arguments = arguments,
	        _this = this;

	    this._observer = new MutationObserver(function (records) {
	      console.log('MO HANDLER', 'started', Array.from(_arguments));

	      if (records.every(function (r) {
	        return r.addedNodes.length === 0;
	      })) {
	        console.log('NO added nodes. Terminating!');
	        return;
	      }

	      _this._observer.disconnect();

	      _this._createButtons();
	      _this._startObserving();
	    });
	  };

	  ButtonsController.prototype._startObserving = function _startObserving() {
	    this._observer.disconnect();

	    var observedNode = document.querySelector('.stream__list,.l-content') || document;

	    this._observer.observe(observedNode, { subtree: true, childList: true });
	  };

	  ButtonsController.prototype._createButtonsOnElem = function _createButtonsOnElem(elem) {
	    console.log('Creating button on elem', elem);

	    elem.dataset.sthy = true;

	    var container = elem.querySelector('.sc-button-group');
	    var size = this._isListPage ? 'small' : 'medium';
	    container.appendChild(this._createButtonNode({ action: 'play', text: 'Slay', size: size }));
	    container.appendChild(this._createButtonNode({ action: 'store', text: 'Store', size: size }));
	  };

	  ButtonsController.prototype._createButtonNode = function _createButtonNode(_ref) {
	    var action = _ref.action;
	    var text = _ref.text;
	    var size = _ref.size;

	    var button = document.createElement('button');
	    button.innerHTML = text;
	    button.classList.add('sthy-button', 'sc-button', 'sc-button-' + size, 'sc-button-responsive');
	    button.dataset['action'] = action;

	    button.addEventListener('click', this, true);

	    return button;
	  };

	  ButtonsController.prototype._createButtons = function _createButtons() {
	    var _this2 = this;

	    var selectorPrefix = ':not([data-sthy])';

	    var elements = this._isListPage ? document.querySelectorAll('.soundList__item' + selectorPrefix) : document.querySelectorAll('.l-listen-wrapper' + selectorPrefix);

	    [].concat(_toConsumableArray(elements)).forEach(function (elem) {
	      return _this2._createButtonsOnElem(elem);
	    });
	  };

	  ButtonsController.prototype.handleEvent = function handleEvent(evt) {
	    evt.preventDefault();
	    evt.stopPropagation();

	    var action = evt.target.dataset.action;
	    var container = evt.target.closest('.soundList__item');

	    console.log('Action \'' + action + '\' clicked');

	    switch (action) {
	      case 'play':
	        var url = this._isListPage ? container.querySelector('.sound__coverArt').getAttribute('href') : window.location.href;

	        this._sendCommand(action, { url: url });

	        break;

	      case 'store':
	        break;
	    }
	  };

	  ButtonsController.prototype._sendCommand = function _sendCommand(command, data) {
	    if (!chrome.runtime) {
	      window.location.reload();
	    }

	    chrome.runtime.sendMessage({ command: command, data: data }, function (response) {});
	  };

	  _createClass(ButtonsController, [{
	    key: '_isListPage',
	    get: function get() {
	      if (typeof this.__isListPage === 'undefined') {
	        this.__isListPage = !_consts2.default.TRACK_PAGE_RE.test(window.location.href);
	      }
	      return this.__isListPage;
	    }
	  }]);

	  return ButtonsController;
	}();

	var PageLifecycleChecked = function () {
	  function PageLifecycleChecked() {
	    _classCallCheck(this, PageLifecycleChecked);

	    this._bindEvents();
	  }

	  PageLifecycleChecked.prototype._bindEvents = function _bindEvents() {
	    var _this3 = this;

	    document.addEventListener('DOMContentLoaded', function () {
	      return _this3._sendLifecycleEvent('content-loaded');
	    });
	    window.onload = function () {
	      return _this3._sendLifecycleEvent('window-loaded');
	    };
	  };

	  PageLifecycleChecked.prototype._sendLifecycleEvent = function _sendLifecycleEvent(event) {
	    if (!chrome.runtime) {
	      window.location.reload();
	    }

	    console.log('Lifecycle event \'' + event + '\'');

	    chrome.runtime.sendMessage({ command: 'lifecycle', data: { event: event } });
	  };

	  return PageLifecycleChecked;
	}();

	console.log('CONTENT STARTED!!!');

	new ButtonsController();
	new PageLifecycleChecked();

/***/ },

/***/ 5:
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	  value: true
	});
	exports.default = {
	  TRACK_PAGE_RE: /^https:\/\/soundcloud\.com\/[^/]+\/[^/]+/
		};

/***/ }

/******/ });
//# sourceMappingURL=content-buttons.js.map
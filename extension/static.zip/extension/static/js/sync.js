/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports) {

	'use strict';

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	//sc-button-pause
	//sc-button-buffering

	var CLASS = {
	  buffering: 'sc-button-buffering',
	  paused: 'sc-button-pause'
	};

	var Sync = function () {
	  function Sync() {
	    _classCallCheck(this, Sync);

	    this._init();

	    this._initBackgroundConnection();
	  }

	  Sync.prototype._initBackgroundConnection = function _initBackgroundConnection() {
	    var _this = this;

	    this._port = chrome.runtime.connect({ name: 'sync' });

	    this._port.onMessage.addListener(function (request) {
	      return _this._onMessage(request);
	    });
	  };

	  Sync.prototype._init = function _init() {
	    this._playButton = this._findPlayButton();
	    if (!this._playButton) {
	      console.warn('Play button is not presented on the page');
	      return;
	    }

	    this._initMutationObserver();

	    this._scheduleReadinessCheck();
	  };

	  Sync.prototype._scheduleReadinessCheck = function _scheduleReadinessCheck() {
	    var _this2 = this;

	    var timeout = 5000;

	    if (this._readinessCheckTimeout) {
	      console.log('Clearing schedule timeout');
	      clearTimeout(this._readinessCheckTimeout);
	    }

	    console.log('Scheduling readiness check after ' + timeout + 'ms');
	    this._readinessCheckTimeout = setTimeout(function () {
	      return _this2._checkReadiness();
	    }, timeout);
	  };

	  Sync.prototype._stopObserving = function _stopObserving() {
	    var options = arguments.length <= 0 || arguments[0] === undefined ? { dom: true, attr: true, playback: true } : arguments[0];

	    console.log('Stop observing...', options);

	    options.dom && this._domObserver.disconnect();
	    options.attr && this._attrObserver.disconnect();
	    options.playback && this._playbackObserver.disconnect();
	  };

	  Sync.prototype._startObserving = function _startObserving() {
	    var options = arguments.length <= 0 || arguments[0] === undefined ? { dom: true, attr: true, playback: true } : arguments[0];

	    console.log('Start observing...', options);

	    var subtreeOptions = { subtree: true, childList: true };
	    var attrOptions = { attributes: true, attributeOldValue: true };

	    options.dom && this._domObserver.observe(document, subtreeOptions);
	    options.attr && this._attrObserver.observe(this._playButton, attrOptions);
	    if (options.playback) {
	      this._playbackObserver.observe(this._findPlaybackContainer(), subtreeOptions);
	    }
	  };

	  Sync.prototype._checkReadiness = function _checkReadiness() {
	    console.log('Checking track status after timeout.');
	    if (this._isPaused()) {
	      console.log('Track is paused. READY! Sending command');
	      this._sendCommand('ready');

	      // stop all observers
	      this._stopObserving();
	    } else {
	      console.log('Track is in undefined state. NOT READY!', this._playButton.classList);
	    }
	  };

	  Sync.prototype._initMutationObserver = function _initMutationObserver() {
	    var _this3 = this;

	    console.log('Init observing...');
	    this._domObserver = new MutationObserver(function (records) {
	      return _this3._onDomMutation(records);
	    });
	    this._attrObserver = new MutationObserver(function (records) {
	      return _this3._onAttrMutation(records);
	    });
	    this._playbackObserver = new MutationObserver(function (records) {
	      return _this3._onPlaybackMutation(records);
	    });

	    this._startObserving({ dom: true, attr: true });
	  };

	  Sync.prototype._isPaused = function _isPaused() {
	    // sc-button-play playButton sc-button m-stretch

	    var classList = this._playButton.classList;


	    return !classList.contains(CLASS.paused) && !classList.contains(CLASS.buffering);
	  };

	  Sync.prototype._isPlaying = function _isPlaying() {
	    // sc-button-play playButton sc-button m-stretch sc-button-pause

	    var classList = this._playButton.classList;


	    return classList.contains(CLASS.paused) && !classList.contains(CLASS.buffering);
	  };

	  Sync.prototype._isBuffering = function _isBuffering() {
	    var classList = this._playButton.classList;


	    return classList.contains(CLASS.buffering);
	  };

	  Sync.prototype._pause = function _pause() {
	    var isPlaying = this._isPlaying();
	    var isBuffering = this._isBuffering();

	    console.log('Attempt to pause', 'Playing \'' + isPlaying + '\', buffering \'' + isBuffering + '\'');

	    if (!this._isPaused()) {
	      console.log('Track is playing. Click pause');
	      this._playButton.click();
	    }
	  };

	  Sync.prototype._play = function _play() {
	    console.log('Attempt to play');

	    // can't play if buffering
	    if (this._isBuffering()) {
	      console.log('Can\'t play, buffering');
	      return false;
	    }

	    // play if paused
	    if (this._isPaused()) {
	      console.log('Track is paused. Clicking play');
	      this._playButton.click();
	      return true;
	    }

	    console.log('Track is playing. Can\'t play it');

	    return false;
	  };

	  Sync.prototype._findPlayButton = function _findPlayButton() {
	    return document.querySelector('.playButton');
	  };

	  Sync.prototype._findPlaybackContainer = function _findPlaybackContainer() {
	    return document.querySelector('.playbackTimeline__timePassed');
	  };

	  Sync.prototype._findPlaybackTime = function _findPlaybackTime() {
	    return document.querySelectorAll('.playbackTimeline__timePassed span')[1];
	  };

	  Sync.prototype._onDomMutation = function _onDomMutation(records) {
	    console.log('DOM mutation', records.map(function (r) {
	      return r.addedNodes;
	    }));
	    if (records.every(function (r) {
	      return r.addedNodes.length === 0;
	    })) {
	      console.log('No added nodes. Nothing interesting');
	      return;
	    }

	    var playButton = this._findPlayButton();
	    if (playButton !== this._playButton) {
	      console.log('Replacing PLAY BUTTON pointer, relaunching observers');
	      this._playButton = playButton;
	      this._stopObserving({ attr: true });
	      this._startObserving({ attr: true });

	      this._scheduleReadinessCheck();
	    }
	  };

	  Sync.prototype._onAttrMutation = function _onAttrMutation(records) {
	    console.log('Attr mutation', records, this._playButton.classList.toString());
	    if (this._isPlaying()) {
	      console.log('Is playing. Pause!');
	      this._pause();
	    }
	  };

	  Sync.prototype._onPlaybackMutation = function _onPlaybackMutation(records) {
	    var time = this._findPlaybackTime().textContent;
	    console.log('Playback mutation', time);

	    this._sendCommand('time', { time: time });
	  };

	  Sync.prototype._sendCommand = function _sendCommand(command, data) {
	    this._port.postMessage({ command: command, data: data });
	  };

	  Sync.prototype._onMessage = function _onMessage(request) {
	    console.log('Sync port message came', request);
	    switch (request.command) {
	      case 'start':
	        return this._start();

	      case 'correct':
	        return this._correct(request.data.diff);
	    }
	  };

	  Sync.prototype._correct = function _correct(diff) {
	    var _this4 = this;

	    if (this._correctTimeout) {
	      return console.log('Skip correction.');
	    }

	    console.log('Correcting on ' + diff + 'sec');

	    this._stopObserving({ playback: true });
	    this._pause();

	    this._correctTimeout = setTimeout(function () {
	      console.log('Correction timeout fired! Starting');
	      _this4._correctTimeout = null;
	      _this4._start();
	    }, diff * 1000);
	  };

	  Sync.prototype._start = function _start() {
	    this._playbackTime = this._findPlaybackTime();
	    this._play();

	    this._startObserving({ playback: true });
	  };

	  return Sync;
	}();

	console.log('SYNC injected');

	new Sync();

/***/ }
/******/ ]);
//# sourceMappingURL=sync.js.map